# ComfortMatch

Static HVAC lead-generation landing page prepared for GitHub Pages.

## Publish
1. Create a public GitHub repository.
2. Upload `index.html` and `.nojekyll` to the repository root.
3. In Settings → Pages, publish from the `main` branch and `/ (root)`.
4. Open the generated GitHub Pages URL.

The form is configured to submit to the ComfortMatch Google Apps Script endpoint supplied during setup.
